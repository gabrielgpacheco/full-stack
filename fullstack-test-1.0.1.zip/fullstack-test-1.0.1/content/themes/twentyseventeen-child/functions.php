<?php

/**
 * Load custom classes
 */
require __DIR__ . '/inc/Theme.php';

new LottaLeben\Theme();
